########################
# Copyright(c) 2014-2017 DongGuan HeWei Communication Technologies Co. Ltd.
# file    reset_usb_bus.sh
# brief   
# author  Shi Kai
# version 1.0.0
# date    23Feb17
########################
#!/bin/bash
reset_usb /dev/bus/usb/001/001
