########################
# Copyright(c) 2014-2016 DongGuan HeWei Communication Technologies Co. Ltd.
# file    start_mic_record.sh
# brief   
# author  Shi Kai
# version 1.0.0
# date    19Aug16
########################
#!/bin/bash
#open mic mixer and set to max volume
tinymix 9 255 255
tinymix 48 63 63
#L2 R2 volume
#tinymix 45 7 7
#AUX volume
#tinymix 46 7 7
#left
#right
#L2
#tinymix 52 1
#R2
#tinymix 55 1
