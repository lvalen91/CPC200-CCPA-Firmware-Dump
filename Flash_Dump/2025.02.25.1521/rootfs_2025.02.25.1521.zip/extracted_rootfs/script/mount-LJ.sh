########################
# Copyright(c) 2014-2015 DongGuan HeWei Communication Technologies Co. Ltd.
# file    mount-LJ.sh
# brief   
# author  LI JIAN
# version 1.0.0
# date    12Jul15
########################
#!/bin/bash
mount -t nfs -o nolock 192.168.31.144:/home/lijian /mnt/LJ

