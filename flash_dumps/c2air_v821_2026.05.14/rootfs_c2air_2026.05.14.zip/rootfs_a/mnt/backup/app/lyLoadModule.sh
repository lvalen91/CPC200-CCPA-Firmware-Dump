#!/bin/sh

#LY_BOOT_MODE=$1
WIFIPATH=/etc/wifi

if [ -f /tmp/ap_p2p_mixed ];then
	killall hostapd
	killall udhcpd
	killall wpa_supplicant
	killall p2p_wps_pbc.sh
	sleep 1
	killall -9 udhcpd
	killall -9 wpa_supplicant
	killall -9 hostapd
fi

if [ -f /sys/ly_private/wifi_ch ];then
	wifi_ch=$(cat /sys/ly_private/wifi_ch)
	echo "wifi_ch=$wifi_ch"
	if [ $wifi_ch != "0" ];then
		export WIFI_AP_CH=$wifi_ch
	fi
fi

if [ $WIFI_AP_CH == "1" ];then
	export WIFI_P2P_FREQ=2412
elif [ $WIFI_AP_CH == "6" ];then
	export WIFI_P2P_FREQ=2437
elif [ $WIFI_AP_CH == "11" ];then
	export WIFI_P2P_FREQ=2462
elif [ $WIFI_AP_CH == "40" ];then
	export WIFI_P2P_FREQ=5200
elif [ $WIFI_AP_CH == "44" ];then
	export WIFI_P2P_FREQ=5220
elif [ $WIFI_AP_CH == "48" ];then
	export WIFI_P2P_FREQ=5240	
elif [ $WIFI_AP_CH == "149" ];then
	export WIFI_P2P_FREQ=5745
elif [ $WIFI_AP_CH == "153" ];then
	export WIFI_P2P_FREQ=5765
elif [ $WIFI_AP_CH == "157" ];then
	export WIFI_P2P_FREQ=5785	
elif [ $WIFI_AP_CH == "161" ];then
	export WIFI_P2P_FREQ=5805
else
	export WIFI_P2P_FREQ=5180
fi

echo "WIFI_P2P_FREQ=$WIFI_P2P_FREQ"

if [ -z "$WIFI_P2P_FREQ" ];then
	export WIFI_P2P_FREQ=5180
fi
if [ -z "$IPADDR" ];then
	export IPADDR=192.168.1.101
fi
if [ -z "$SUBNETMASK" ];then
	export SUBNETMASK=255.255.255.0
fi
if [ -z "$P2P_IPADDR" ];then
	export P2P_IPADDR=192.168.43.1
fi
if [ -z "$P2P_SUBNETMASK" ];then
	export P2P_SUBNETMASK=255.255.255.0
fi
if [ -f $WORKDIR/udhcpd-cp.conf ];then
	cp -rf $WORKDIR/udhcpd-cp.conf /tmp/udhcpd_ap.conf
else
	cp -rf $WIFIPATH/udhcpd-cp.conf /tmp/udhcpd_ap.conf
fi
if [ -f $WORKDIR/p2p.conf ];then
	cp -rf $WORKDIR/p2p.conf /tmp/p2p.conf
else
	cp -rf $WIFIPATH/p2p.conf /tmp/p2p.conf
fi
if [ -f $WORKDIR/udhcpd-hicar.conf ];then
	cp -rf $WORKDIR/udhcpd-hicar.conf /tmp/udhcpd_p2p.conf
else
	cp -rf $WIFIPATH/udhcpd-hicar.conf /tmp/udhcpd_p2p.conf
fi

if [ ! -f /tmp/blink ];then
	blink.sh ${LY_BOOT_MODE} ${LY_DEBUG_MODE} &
	touch /tmp/blink
fi

wlan0=`ifconfig -a | grep wlan0`
trial=0
while [ -z "$wlan0" ] && [ $trial -le 40 ]
do 
    sleep 0.2
    trial=$(($trial + 1 ))
    wlan0=`ifconfig -a | grep wlan0`
done

if [ $trial -gt 40 ];then
    echo wlan0 not found
    exit -1
fi

#launch ap & p2p
mkdir -p /var/wifi/misc
mkdir -p /var/run/hostapd/
mkdir -p /var/run/wpa_supplicant
rm -f /dev/random
ln -s /dev/urandom /dev/random
echo 1 > /proc/sys/net/ipv6/conf/wlan0/disable_ipv6
ifconfig wlan0 up

ifconfig wlan0 $IPADDR netmask $SUBNETMASK
sleep 1

sed -i "/^device_name=/c\device_name=${WIFI_NAME}" /tmp/p2p.conf
wpa_supplicant -i wlan0 -c /tmp/p2p.conf -Dnl80211 &

sleep 1
freq_param="freq=$WIFI_P2P_FREQ"
wpa_cli p2p_group_add $freq_param
sleep 1
status=`wpa_cli status | awk '/freq=/ {print $1}'`
echo "status=$status"
trial=0
while [ "$status" != "$freq_param" ] && [ $trial -le 5 ]
do
	trial=$(($trial + 1 ))
	wpa_cli p2p_group_add $freq_param
	sleep 1
	status=`wpa_cli status | awk '/freq=/ {print $1}'`
	echo "status=$status"
done

echo "trial=$trial"
if [ $trial -gt 5 ];then
	echo p2p go mode set fail
	exit -1
fi


status=`ifconfig -a | grep p2p-wlan0-0`
trial=0
while [ -z "$status" ] && [ $trial -le 20 ]
do 
	sleep 0.2
	trial=$(($trial + 1 ))
	status=`ifconfig -a | grep p2p-wlan0-0`
done

if [ $trial -gt 20 ];then
	echo p2p-wlan0-0 not found
	exit -1
fi

ifconfig p2p-wlan0-0 $P2P_IPADDR netmask $P2P_SUBNETMASK
sed -i '/wlan0/c\interface p2p-wlan0-0' /tmp/udhcpd_p2p.conf
sed -i "s/opt\trouter\t0.0.0.0/opt\trouter\t$IPADDR/" /tmp/udhcpd_p2p.conf

logwrapper udhcpd /tmp/udhcpd_p2p.conf &

echo "run $WIFIPATH/hostapd"
rm -fr /tmp/ap_p2p_mixed
lyhostapd
touch /tmp/ap_p2p_mixed

logwrapper udhcpd /tmp/udhcpd_ap.conf &

echo 3 > /proc/sys/vm/drop_caches

#p2p wpc
p2p_wps_pbc.sh &
