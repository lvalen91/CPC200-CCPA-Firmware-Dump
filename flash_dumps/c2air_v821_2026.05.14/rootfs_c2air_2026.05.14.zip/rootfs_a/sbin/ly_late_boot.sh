#!/bin/sh

sleep 5

data_check

if [ $LY_SDCARD_ENABLE == '1' ];then
	udev.sh &
fi


