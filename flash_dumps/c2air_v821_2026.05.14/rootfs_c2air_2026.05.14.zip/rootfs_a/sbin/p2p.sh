#!/bin/sh

mkdir -p /var/wifi/misc
mkdir -p /var/run/hostapd

export WIFIPATH=/etc/wifi

if [ -z "$LY_LINK_TYPE" ];then
	export LY_LINK_TYPE=`fw_printenv -n ly_link_type`
fi

if [ ! -L /dev/random ];then
	rm -f /dev/random
	ln -s /dev/urandom /dev/random
fi

if [ -z "$WIFI_P2P_FREQ" ];then
	export WIFI_P2P_FREQ=5180
fi

case "$1" in
	start)
	if [ -f /tmp/ap_p2p_mixed ]; then
		p2p.sh stop
		sleep 1
	fi
	echo "Launch Wifi module p2p Mode..."
	
	mkdir -p /var/run/wpa_supplicant
	
	wlan0=`ifconfig -a | grep wlan0`
	trial=0
	while [ -z "$wlan0" ] && [ $trial -le 10 ]
	do 
		sleep 0.5
		trial=$(($trial + 1 ))
		wlan0=`ifconfig -a | grep wlan0`
	done

	if [ $trial -gt 10 ];then
		echo wlan0 not found
		exit -1
	fi

	if [ -z "$IPADDR" ];then
		export IPADDR=192.168.1.101
	fi
	

	if [ -z "$SUBNETMASK" ];then
		export SUBNETMASK=255.255.255.0
	fi

	ifconfig wlan0 up
	if [ "$WIFI_MODULE" == "aic8800" ] || [ "$WIFI_MODULE" == "8733bs" ] || [ "$WIFI_MODULE" == "8822bs" ];then
		if [ $LY_LINK_TYPE == 'hicar' ];then
			ifconfig wlan0 $IPADDR netmask $SUBNETMASK
		else
			ifconfig wlan0 192.168.43.1 netmask $SUBNETMASK
		fi
	else
		ifconfig wlan0 $IPADDR netmask $SUBNETMASK
	fi
	
	cp $WIFIPATH/p2p.conf /tmp/
	sed -i "/^device_name=/c\device_name=${WIFI_NAME}" /tmp/p2p.conf
	wpa_supplicant -i wlan0 -c /tmp/p2p.conf -Dnl80211 &
	
	sleep 1
	
	if [ "$WIFI_MODULE" == "aic8800" ];then
		wpa_cli p2p_find
	fi
	
	freq_param="freq=$WIFI_P2P_FREQ"
	wpa_cli p2p_group_add $freq_param
	sleep 1
	status=`wpa_cli status | awk '/freq=/ {print $1}'`
	echo "status=$status"
	trial=0
	while [ "$status" != "$freq_param" ] && [ $trial -le 5 ]
	do
		trial=$(($trial + 1 ))
		wpa_cli p2p_group_add $freq_param
		sleep 1
		status=`wpa_cli status | awk '/freq=/ {print $1}'`
		echo "status=$status"
	done
	
	echo "trial=$trial"

	if [ $trial -gt 5 ];then
		echo p2p go mode set fail
		exit -1
	fi
	
	if [ -f /tmp/udhcpd.conf ];then
		rm /tmp/udhcpd.conf
	fi
	
	if [ $LY_LINK_TYPE == 'hicar' ];then
		cp $WIFIPATH/udhcpd-hicar.conf /tmp/udhcpd.conf
	else
		cp $WIFIPATH/udhcpd-cp.conf /tmp/udhcpd.conf
	fi
	
	if [ "$WIFI_MODULE" == "aic8800" ] || [ "$WIFI_MODULE" == "8733bs" ] || [ "$WIFI_MODULE" == "8822bs" ];then
		status=`ifconfig -a | grep p2p-wlan0-0`
		trial=0
		while [ -z "$status" ] && [ $trial -le 20 ]
		do 
			sleep 0.2
			trial=$(($trial + 1 ))
			status=`ifconfig -a | grep p2p-wlan0-0`
		done

		if [ $trial -gt 20 ];then
			echo p2p-wlan0-0 not found
			exit -1
		fi

		if [ $LY_LINK_TYPE == 'hicar' ];then
			ifconfig p2p-wlan0-0 192.168.43.1 netmask 255.255.255.0
		else
			ifconfig p2p-wlan0-0 $IPADDR netmask 255.255.255.0
		fi
		sed -i '/wlan0/c\interface p2p-wlan0-0' /tmp/udhcpd.conf
	fi
	
	udhcpd /tmp/udhcpd.conf &
	
	p2p_wps_pbc.sh &
	
    ;;
    stop)
	echo " Kill all process of p2p Mode"
	killall p2p_wps_pbc.sh
	killall p2p_mode.sh
	killall udhcpd
	killall wpa_supplicant
	ifconfig wlan0 down
	
	killall -9 p2p_wps_pbc.sh
	killall -9 p2p_mode.sh
	killall -9 udhcpd
	killall -9 wpa_supplicant
    ;;
    *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

