#!/bin/sh

LY_BOOT_MODE=`fw_printenv -n ly_boot_mode=`

if [ $LY_BOOT_MODE == 'update' ];then
	wpa_cli wps_pbc

	while [ true == true ]
	do
		sleep 100
		wpa_cli wps_pbc
	done
fi
