#!/bin/sh

#rm -fr /mnt/UDISK/*
rm -fr /mnt/UDISK/update_flag
sync
