#!/bin/sh

mkdir -p /var/wifi/misc
mkdir -p /var/run/hostapd

WIFIPATH=/etc/wifi

case "$1" in
  start)
  	echo "Launch Wifi module AP Mode ..."

	wlan0=`ifconfig -a | grep wlan0`
	trial=0
	while [ -z "$wlan0" ] && [ $trial -le 10 ]
	do 
		sleep 0.5
		trial=$(($trial + 1 ))
		wlan0=`ifconfig -a | grep wlan0`
	done

	if [ $trial -gt 10 ];then
		echo wlan0 not found
		exit -1
	fi

	if [ -z "$IPADDR" ];then
		export IPADDR=192.168.1.101
	fi
	
	if [ -z "$SUBNETMASK" ];then
		export SUBNETMASK=255.255.255.0
	fi

	ifconfig wlan0 up
	ifconfig wlan0 $IPADDR netmask $SUBNETMASK
	sleep 0.2
	logwrapper udhcpd $WIFIPATH/udhcpd-cp.conf 

	echo "run $WIFIPATH/hostapd"
	cp $WIFIPATH/hostapd.conf /tmp/
	sed -i "/^ssid=/c\ssid=${WIFI_NAME}" /tmp/hostapd.conf
	logwrapper hostapd -B /tmp/hostapd.conf                                

;;
  stop)
	echo " Kill all process of AP Mode"
	killall udhcpd
	killall hostapd
	ifconfig wlan0 0.0.0.0
	ifconfig wlan0 down
	killall -9 udhcpd
	killall -9 hostapd
;;
  restart)
	echo " restart AP Mode"
	

;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

