#!/bin/sh

if [ -z "$IPADDR" ];then
	export IPADDR=192.168.1.101
fi

if [ -z "$SUBNETMASK" ];then
	export SUBNETMASK=255.255.255.0
fi

echo "update mode load wifi.sh "

LY_LINK_TYPE=`fw_printenv -n ly_link_type`

echo "LY_LINK_TYPE=$LY_LINK_TYPE"

WIFIPATH=/etc/wifi
MODULE_PATH=/lib/modules/4.9.191

echo "WIFI_MODULE=$WIFI_MODULE"
if [ "$WIFI_MODULE" == "8821cs" ];then
insmod ${MODULE_PATH}/$WIFI_MODULE.ko rtw_vht_enable=2
elif [ "$WIFI_MODULE" == "aic8800" ];then
insmod ${MODULE_PATH}/aic8800_bsp.ko
insmod ${MODULE_PATH}/aic8800_fdrv.ko
elif [ "$WIFI_MODULE" == "8873bs" ];then
insmod ${MODULE_PATH}/$WIFI_MODULE.ko
else
exit 0
fi

wlan0=`ifconfig -a | grep wlan0`
trial=0
while [ -z "$wlan0" ] && [ $trial -le 40 ]
do 
    sleep 0.2
    trial=$(($trial + 1 ))
    wlan0=`ifconfig -a | grep wlan0`
done

if [ $trial -gt 40 ];then
    echo wlan0 not found
    exit -1
fi

mkdir -p /var/wifi/misc

rm -f /dev/random
ln -s /dev/urandom /dev/random
ifconfig wlan0 up


if [ $LY_LINK_TYPE == 'hicar' ];then
	p2p.sh start
else
	ap.sh start
fi



