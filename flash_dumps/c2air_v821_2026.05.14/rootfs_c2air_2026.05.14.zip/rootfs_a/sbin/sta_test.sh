#!/bin/sh

mkdir -p /var/wifi/misc
mkdir -p /var/run/hostapd

export WIFIPATH=/etc/wifi
MODULE_PATH=/lib/modules/4.9.191

if [ -z "$LY_LINK_TYPE" ];then
	export LY_LINK_TYPE=`fw_printenv -n ly_link_type`
fi

if [ ! -L /dev/random ];then
	rm -f /dev/random
	ln -s /dev/urandom /dev/random
fi

case "$1" in
	start)
	
	echo "Launch Wifi module sta Mode..."
	ap.sh stop
	p2p.sh stop
	sta_test.sh stop
	
	sleep 1
	
	mkdir -p /var/run/wpa_supplicant
	
	if [ "`lsmod|grep $WIFI_MODULE`" == "" ]; then
		echo "wifi modu1e is $WIFI_MODULE.ko"
		if [ "$WIFI_MODULE" == "8821cs" ];then
			if [ -f /mnt/customer/modules/$WIFI_MODULE.ko ];then
				insmod /mnt/customer/modules/$WIFI_MODULE.ko rtw_vht_enable=2
			else
				insmod $MODULE_PATH/$WIFI_MODULE.ko rtw_vht_enable=2
			fi
		elif [ "$WIFI_MODULE" == "aic8800" ];then
			if [ -f /sys/devices/virtual/misc/ly_misc_dev/ly/app_firmware ];then
				if [ -d /mnt/customer/firmware ];then
					echo -n "/mnt/customer/firmware" > /sys/devices/virtual/misc/ly_misc_dev/ly/app_firmware
				fi
			fi
			
			if [ -f /mnt/customer/modules/aic8800_bsp.ko ];then
				insmod /mnt/customer/modules/aic8800_bsp.ko
			else
				insmod $MODULE_PATH/aic8800_bsp.ko
			fi
			
			if [ -f /mnt/customer/modules/aic8800_fdrv.ko ];then
				insmod /mnt/customer/modules/aic8800_fdrv.ko
			else
				insmod $MODULE_PATH/aic8800_fdrv.ko
			fi
		elif [ "$WIFI_MODULE" == "ssv6x5x" ];then
			if [ -f /mnt/customer/modules/$WIFI_MODULE.ko ];then
				insmod /mnt/customer/modules/$WIFI_MODULE.ko stacfgpath=/etc/firmware/ssv6x5x-wifi.cfg
			else
				insmod $MODULE_PATH/$WIFI_MODULE.ko stacfgpath=/etc/firmware/ssv6x5x-wifi.cfg
			fi
		elif [ "$WIFI_MODULE" == "8733bs" ];then
			if [ -f /mnt/customer/modules/$WIFI_MODULE.ko ];then
				insmod /mnt/customer/modules/$WIFI_MODULE.ko
			else
				insmod $MODULE_PATH/$WIFI_MODULE.ko
			fi
		elif [ "$WIFI_MODULE" == "8822bs" ];then
			if [ -f /mnt/customer/modules/$WIFI_MODULE.ko ];then
				insmod /mnt/customer/modules/$WIFI_MODULE.ko
			else
				insmod $MODULE_PATH/$WIFI_MODULE.ko
			fi
		else
			echo "not $WIFI_MODULE driver"
			exit 0
		fi
	fi

	wlan0=`ifconfig -a | grep wlan0`
	trial=0
	while [ -z "$wlan0" ] && [ $trial -le 10 ]
	do 
		sleep 0.5
		trial=$(($trial + 1 ))
		wlan0=`ifconfig -a | grep wlan0`
	done

	if [ $trial -gt 10 ];then
		echo wlan0 not found
		exit -1
	fi


	ifconfig wlan0 up
	
	cat > /tmp/sta_test.conf <<EOF
ctrl_interface=/var/run/wpa_supplicant
update_config=0

network={
key_mgmt=NONE
disabled=1
}
EOF
	
	cp $WIFIPATH/sta_test.conf /tmp/
	wpa_supplicant -i wlan0 -c /tmp/sta_test.conf -B&
	sleep 1

	if [ "$DUAL_WIFI" = "1" ]; then
		ly_wifi1.sh
	fi
	
	;;
	stop)
	echo " Kill all process of sta Mode"
	killall wpa_supplicant
	ifconfig wlan0 down
	if [ "$DUAL_WIFI" = "1" ]; then
		ifconfig wlan1 down
	fi
	
	killall -9 wpa_supplicant
	;;
	*)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac


