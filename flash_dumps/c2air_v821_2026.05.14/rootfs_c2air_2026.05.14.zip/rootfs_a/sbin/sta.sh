#!/bin/sh

WIFIPATH=/etc/wifi

if [ -f "$WIFIPATH/sta.conf" ];then
	cp -fr $WIFIPATH/sta.conf /tmp/sta.conf
fi

case "$1" in
	start)
	echo "Launch Wifi module STA Mode..."

	wlan0=`ifconfig -a | grep wlan0`
	trial=0
	while [ -z "$wlan0" ] && [ $trial -le 10 ]
	do 
		sleep 0.5
		trial=$(($trial + 1 ))
		wlan0=`ifconfig -a | grep wlan0`
	done

	if [ $trial -gt 10 ];then
		echo wlan0 not found
		exit -1
	fi

	ifconfig wlan0 up
	
	wpa_supplicant -Dnl80211 -iwlan0 -c /tmp/sta.conf -B

	udhcpc -i wlan0 -T 1 -A 1 -s /etc/udhcpc.script

    ;;
    stop)
	echo " Kill all process of STA Mode"
	killall udhcpc
	killall wpa_supplicant
	ifconfig wlan0 down
	#rmmod $WIFI_MODULE
    ;;
    *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

