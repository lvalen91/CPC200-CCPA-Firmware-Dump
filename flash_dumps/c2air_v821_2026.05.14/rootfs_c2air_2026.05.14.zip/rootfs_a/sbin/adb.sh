#!/bin/sh

killall adbd
setusbconfig none
setusbconfig adb
adbd  > /dev/null 2>&1 &

