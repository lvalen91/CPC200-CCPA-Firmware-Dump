#!/bin/sh

echo 0 > /sys/devices/virtual/misc/ly_misc_dev/ly/bt_rst

if echo "$BT_NAME" | grep -q ' '; then
    BT_ARG="-N$BT_NAME"
else
    BT_ARG=-N$BT_NAME
fi

nice -n -16 "$WORKDIR/btapp" "$BT_ARG" -T/dev/ttyS1 -B -M
